-----

<p align= "center">
  <kbd>
    <img  src="https://raw.githubusercontent.com/waxnet/NetWare/main/.github/workflows/icon.png">
  </kbd>
</p>

-----

### <p align="center">🕸️ NetWare 🕸️</p>
<p align= "center">
  <img src="https://img.shields.io/github/last-commit/waxnet/NetWare">
  <img src="https://img.shields.io/github/license/waxnet/NetWare">
  <br>
  <img src="https://img.shields.io/github/stars/waxnet/NetWare">
  <img src="https://img.shields.io/github/forks/waxnet/NetWare">
  <img src="https://img.shields.io/github/downloads/waxnet/NetWare/total.svg">
  <br>
  <img src="https://img.shields.io/github/languages/top/waxnet/NetWare">
</p>

-----

### <p align="center">🔑 Usage 🔑</p>
<p align="center"><i><b>
After you've downloaded and extracted the latest release, open 1v1.LOL
and run "inject.cmd" to load NetWare.
</b></i></p>

-----

### <p align="center">📜 Features 📜</p>

```
• Combat
      + Soft Aim
            - Enabled
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - Smoothing (5 - 10)
            - FOV Color
      + Silent Aim
            - Enabled
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - FOV Color
      + Weapons
            - No Recoil
            - Infinite Ammo
            - Rapid Fire

• Visual
      + ESP
            - Tracers
            - Boxes
            - Skeleton
            - Info
            - Nametags
      + FOV Changer
            - Enabled
            - Amount (20 - 150)

• Movement
      + Speed
            - Enabled
            - Amount (1 - 10)
      + Fly
            - Enabled

• Exploits
      + Player
            - Godmode
            - Instant Land
            - Infinite Materials
            - Anti Freeze
      + Other
            - Auto Play
      + World
            - Kill All
            - Freeze Players
            - Destroy Buildings
            - Open Crates
            - Building Spam
            - Rig Spam
            - Instant Break
      + Locker
            - Unlock Emotes
            - Unlock Stickers
            - Skin Changer
            - Pickaxe Changer

• Settings
      + Config Manager
            - Save
            - Delete
      + Config Loader
```

-----

### <p align="center">💡 Ideas 💡</p>

    • Fix my shitty code.

<p align="center"><i><b>Feel free to submit any idea by making a pull request on this repository!</b></i></p>

-----

### <p align="center">💾 Dependencies 💾</p>
<p align="center"><a href="https://github.com/warbler/SharpMonoInjector">SharpMonoInjector</a></p>

-----

### <p align="center">⚠️ Disclaimer ⚠️</p>

<p align="center"><i><b>This program is meant for educational purposes only.</b></i></p>

-----

### <p align="center"><a href="https://github.com/waxnet">waxnet</a></p>